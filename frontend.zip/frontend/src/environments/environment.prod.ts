export const environment = {
  production: true,
  baseUrl: 'https://movie-be-hecl.onrender.com' // cập nhật sau khi deploy BE
};
